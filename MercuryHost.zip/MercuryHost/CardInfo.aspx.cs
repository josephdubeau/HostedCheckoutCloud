﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


public partial class _CardInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void cmdInit_Click(object sender, EventArgs e)
    {
        //Set the URL variables.
        string returnURL = "http://localhost:61805/MercuryHost/CardInfo_SampleCode.aspx";
        string orderCompleteURL = "http://localhost:61805/MercuryHost/CardInfo_SampleCode.aspx";

        string logoURL = ConfigurationManager.AppSettings["LogoURL"];
        //Create the InitializeCardInfo request
        HCService.InitCardInfoRequest hcRequest = new HCService.InitCardInfoRequest();

        //Populated the request fields.
        hcRequest.MerchantID = ConfigurationManager.AppSettings["MerchantID"];
        hcRequest.Password = ConfigurationManager.AppSettings["HCPassword"];
        hcRequest.CardHolderName = "John Jones";
        hcRequest.Frequency = "OneTime";
        hcRequest.ReturnUrl = returnURL;
        hcRequest.ProcessCompleteUrl = orderCompleteURL;
        hcRequest.BackgroundColor = "Gray";
        hcRequest.FontColor = "Black";
        hcRequest.FontSize = "Medium";
        hcRequest.FontFamily = "FontFamily1";
        hcRequest.PageTitle = "Demo Card Info";
        hcRequest.LogoUrl = logoURL;
        hcRequest.DisplayStyle = "Custom";
        hcRequest.SubmitButtonText = "Save Card";
        hcRequest.CancelButtonText = "Cancel Save";
        hcRequest.OperatorID = "OP10";
         

        //Call the InitializeCardInfo Web Service Method.
        HCService.HCServiceSoapClient hcWS = new HCService.HCServiceSoapClient(); 
        //HCService.HCService hcWS = new HCService.HCService();
        HCService.InitCardInfoResponse response = hcWS.InitializeCardInfo(hcRequest);
        

        //Check the responseCode
        if (response.ResponseCode == 0) 
        { 
            //get the CardInfo ID 
            txtCardID.Text = response.CardID; 
        } 
        //Access the response message if needed. 
        lblInitResponseMessage.Text = response.Message;
    
    }

    protected void cmdCheckOut_Click(object sender, EventArgs e)
    {
        //Set the necessary variables before building html. 
        String addCardURL = ConfigurationManager.AppSettings["CardInfoUR"];
        string CardID = this.txtCardID.Text; 
        //Build an html form post to be sent back to the browser. 
        //It will redirect the browser to the Mercury HostedCheckout page. 
        Response.Clear(); 
        Response.Write("<html><head></head>");
        Response.Write("<body onload='document.frmAddCard.submit()'>");
        Response.Write("<form name=frmAddCard method=Post action=" + addCardURL + ">");
        Response.Write("<input name=CardID type=hidden value=" + CardID + ">"); 
        Response.Write("</form>"); 
        Response.Write("</body></html>"); 
        Response.End();

    }
}