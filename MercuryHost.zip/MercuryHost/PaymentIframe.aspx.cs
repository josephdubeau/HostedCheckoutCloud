﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


public partial class _PaymentIframe : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            Session["src"] = "";
        }

    }

    protected void cmdInit_Click(object sender, EventArgs e)
    {
        //Set the URL variables.
        string returnURL = "http://localhost:61805/MercuryHost/ShoppingCart_SampleCode.aspx";
        string orderCompleteURL = "http://localhost:61805/MercuryHost/ShoppingCart_SampleCode.aspx";

        string logoURL = ConfigurationManager.AppSettings["LogoURL"];
        //Create the InitializeCardInfo request
        HCService.InitPaymentRequest hcRequest = new HCService.InitPaymentRequest();

        //Populated the request fields.
        hcRequest.MerchantID = ConfigurationManager.AppSettings["MerchantID"];
        hcRequest.Password = ConfigurationManager.AppSettings["HCPassword"];
        //hcRequest.TranType = "PreAuth";
        hcRequest.TranType = "Sale";
        hcRequest.TotalAmount = 6.00;
        Random rand = new Random();
        hcRequest.Invoice = rand.Next(999999999).ToString();
        hcRequest.CardHolderName = "John Jones";
        hcRequest.AVSAddress = "4 Corporate Square";
        hcRequest.AVSZip = "30329";
        hcRequest.Frequency = "OneTime";
        hcRequest.Memo = "Demo Ecommerce Merchant 1.0";
        hcRequest.ReturnUrl = returnURL;
        hcRequest.ProcessCompleteUrl = orderCompleteURL;
        hcRequest.BackgroundColor = "Gray";
        hcRequest.FontColor = "Black";
        hcRequest.FontSize = "Medium";
        hcRequest.FontFamily = "FontFamily1";
        hcRequest.PageTitle = "Demo Ecommerce Merchant";
        hcRequest.LogoUrl = logoURL;
        hcRequest.DisplayStyle = "Custom";
        hcRequest.OrderTotal = "on";       
        hcRequest.SubmitButtonText = "Submit Order";
        hcRequest.CancelButtonText = "Cancel Order"; 
        hcRequest.Memo = "Agenda v1.0";


        //Call the InitializePayment Web Service Method.
        HCService.HCServiceSoapClient hcWS = new HCService.HCServiceSoapClient(); 

        HCService.InitPaymentResponse response = hcWS.InitializePayment(hcRequest);
        

        //Check the responseCode
        if (response.ResponseCode == 0) 
        { 
            //get the CardInfo ID 
            txtPaymentID.Text    = response.PaymentID;
            Session["PaymentID"] = response.PaymentID;
            Session["src"] = "https://hc.mercurydev.net/Checkoutiframe.aspx?pid=" + txtPaymentID.Text;
        } 
        //Access the response message if needed. 
        lblInitResponseMessage.Text = response.Message;
    
    }

}