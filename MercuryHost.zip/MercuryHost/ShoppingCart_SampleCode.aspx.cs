﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Configuration;

public partial class ShoppingCart_SampleCode : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            String s = Request.Params["PaymentID"].ToString();
            if (String.IsNullOrEmpty(s) == false)
            {
                txtPaymentID.Text = s;

            }

            String t = Request.Params["ReturnCode"].ToString();
            if (String.IsNullOrEmpty(t) == false)
            {
                txtReturnCode.Text = t;
            }

            String r = Request.Params["ReturnMessage"].ToString();
            if (String.IsNullOrEmpty(t) == false)
            {
                txtReturnMessage.Text = r;
            }

            Clean();
        }
    }

    private void Clean()
    {
        txtResponseCode.Text =  "" ;
        txtStatus.Text = "";  
        txtStatusMessage.Text = "";  
        txtDisplayMessage.Text = "";  
        txtToken.Text = "";  
        txtAuthCode.Text = "";   
        txtAvsResult.Text = "";  
        txtCvvResult.Text = "";  
        txtCardType.Text = "";  
        txtRefNo.Text =  "";  
        txtInvoice.Text =  "";  
        txtAcqRefData.Text =  "";  
        txtTaxAmount.Text =  "";  
        txtTransPostTime.Text =  "";  
        txtMaskedAcct.Text = "";   
        txtAmount.Text =  "";  
        txtCardholderName.Text =  "";  
        txtAVSAddress.Text =  "";  
        txtAVSZip.Text =  "";  
        txtTranType.Text =  "";  
        txtPaymentIDExpired.Text =  "";  
        txtCustomerCode.Text =  "";  
        txtMemo.Text = "";   
    }

    protected void cmdVerify_Click(object sender, EventArgs e)
    {
        HCService.PaymentInfoRequest verifyPaymentRequest = new HCService.PaymentInfoRequest();
        verifyPaymentRequest.MerchantID = System.Configuration.ConfigurationManager.AppSettings["MerchantID"];
        verifyPaymentRequest.Password = System.Configuration.ConfigurationManager.AppSettings["HCPassword"];

        verifyPaymentRequest.PaymentID = txtPaymentID.Text;
        //Call the VerifyPayment web method.

        //HCService.HCService hcService = new HCService.HCService();
        HCService.HCServiceSoapClient hcWS = new HCService.HCServiceSoapClient();
        HCService.PaymentInfoResponse response = hcWS.VerifyPayment(verifyPaymentRequest);
        //get the information from the response 

        txtResponseCode.Text     = response.ResponseCode.ToString();
        txtStatus.Text           = response.Status;
        txtStatusMessage.Text    = response.StatusMessage;
        txtDisplayMessage.Text   = response.DisplayMessage;
        txtToken.Text            = response.Token;
        txtAuthCode.Text         = response.AuthCode;
        txtAvsResult.Text        = response.AvsResult;
        txtCvvResult.Text        = response.CvvResult;
        txtCardType.Text         = response.CardType;
        txtRefNo.Text            = response.RefNo;
        txtInvoice.Text          = response.Invoice;
        txtAcqRefData.Text       = response.AcqRefData;
        txtTaxAmount.Text        = response.TaxAmount.ToString();
        txtTransPostTime.Text    = response.TransPostTime.ToString();
        txtMaskedAcct.Text       = response.MaskedAccount;
        txtAmount.Text           = response.Amount.ToString();
        txtCardholderName.Text   = response.CardholderName;
        txtAVSAddress.Text       = response.AVSAddress;
        txtAVSZip.Text           = response.AVSZip;
        txtTranType.Text         = response.TranType;
        txtPaymentIDExpired.Text = response.PaymentIDExpired.ToString(); 
        txtCustomerCode.Text     = response.CustomerCode;
        txtMemo.Text             = response.Memo;

        // save for payment by token example. note: this is for demonstration use only.
        SaveVerify(response.Token, response.MaskedAccount); 
    }


    private void SaveVerify(string Token, string MaskedAcct)
    {

        System.Configuration.Configuration config = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);
        AppSettingsSection appSettings = config.AppSettings;

        appSettings.Settings["Token"].Value = Token;
        appSettings.Settings["MaskedAcct"].Value = MaskedAcct;

        config.Save(ConfigurationSaveMode.Modified);

        ConfigurationManager.RefreshSection("appSettings");
    }
}