﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


public partial class _Payment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void cmdInit_Click(object sender, EventArgs e)
    {
        //Set the URL variables.
        string returnURL = "http://localhost:61805/MercuryHost/ShoppingCart_SampleCode.aspx";
        string orderCompleteURL = "http://localhost:61805/MercuryHost/ShoppingCart_SampleCode.aspx";

        string logoURL = ConfigurationManager.AppSettings["LogoURL"];
        //Create the InitializeCardInfo request
        HCService.InitPaymentRequest hcRequest = new HCService.InitPaymentRequest();

        //Populated the request fields.
        hcRequest.MerchantID = ConfigurationManager.AppSettings["MerchantID"];
        hcRequest.Password = ConfigurationManager.AppSettings["HCPassword"];
        //hcRequest.TranType = "PreAuth";
        hcRequest.TranType = "Sale";
        hcRequest.TotalAmount = 6.00;
        Random rand = new Random();
        hcRequest.Invoice = rand.Next(999999999).ToString();
        hcRequest.CardHolderName = "John Jones";
        hcRequest.AVSAddress = "4 Corporate Square";
        hcRequest.AVSZip = "30329";
        hcRequest.Frequency = "OneTime";
        hcRequest.Memo = "Demo Ecommerce Merchant 1.0";
        hcRequest.ReturnUrl = returnURL;
        hcRequest.ProcessCompleteUrl = orderCompleteURL;
        hcRequest.BackgroundColor = "Gray";
        hcRequest.FontColor = "Black";
        hcRequest.FontSize = "Medium";
        hcRequest.FontFamily = "FontFamily1";
        hcRequest.PageTitle = "Demo Ecommerce Merchant";
        hcRequest.LogoUrl = logoURL;
        hcRequest.DisplayStyle = "Custom";
        hcRequest.OrderTotal = "on";       
        hcRequest.SubmitButtonText = "Submit Order";
        hcRequest.CancelButtonText = "Cancel Order";
        // To view test transactions over the Developer Certification Network, 
        // go to https://www.mercurydev.net/DeveloperReporting.
        // Login using: username: jerry and password: jerry. Filter using your Memo field.
        hcRequest.Memo = ConfigurationManager.AppSettings["Memo"]; ;


        //Call the InitializePayment Web Service Method.
        HCService.HCServiceSoapClient hcWS = new HCService.HCServiceSoapClient(); 

        HCService.InitPaymentResponse response = hcWS.InitializePayment(hcRequest);
        

        //Check the responseCode
        if (response.ResponseCode == 0) 
        { 
            //get the CardInfo ID 
            txtPaymentID.Text    = response.PaymentID;
            Session["PaymentID"] = response.PaymentID;
        } 
        //Access the response message if needed. 
        lblInitResponseMessage.Text = response.Message;
    
    }

    protected void cmdCheckOut_Click(object sender, EventArgs e)
    {
        //Set the necessary variables before building html. 
        String hostedCheckoutURL = ConfigurationManager.AppSettings["HostedCheckoutURL"];
        string paymentID = this.txtPaymentID.Text; 
        //Build an html form post to be sent back to the browser. 
        //It will redirect the browser to the Mercury HostedCheckout page. 
        Response.Clear(); 
        Response.Write("<html><head></head>"); 
        Response.Write("<body onload='document.frmCheckout.submit()'>"); 
        Response.Write("<form name=frmCheckout method=Post action=" + hostedCheckoutURL +  ">"); 
        Response.Write("<input name=PaymentID type=hidden value=" + paymentID + ">"); 
        Response.Write("</form>"); 
        Response.Write("</body></html>"); 
        Response.End();

    }
}