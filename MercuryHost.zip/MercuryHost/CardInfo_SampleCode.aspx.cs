﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Configuration;


public partial class CardInfo_SampleCode : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            String s = Request.Params["CardID"].ToString();
            if (String.IsNullOrEmpty(s) == false)
            {
                txtCardID.Text = s;

            }

            String t = Request.Params["ReturnCode"].ToString();
            if (String.IsNullOrEmpty(t) == false)
            {
                txtReturnCode.Text = t;
            }

            String r = Request.Params["ReturnMessage"].ToString();
            if (String.IsNullOrEmpty(t) == false)
            {
                txtReturnMessage.Text = r;
            }

            Clean();
        }
    }


    private void Clean()
    {

        txtResponseCode.Text      = "";
        txtStatus.Text            = "";
        txtStatusMessage.Text     = "";
        txtDisplayMessage.Text    = "";
        txtToken.Text             = "";
        txtCardUsage.Text         = "";
        txtCardType.Text          = "";
        txtOperatorID.Text        = "";
        txtMaskedAcct.Text        = "";
        txtCardholderName.Text    = "";
        txtTranType.Text          = "";
        txtCardIDExpired.Text     = "";
    }


    protected void cmdVerify_Click(object sender, EventArgs e)
    {
        //create the request 
        HCService.CardInfoRequest verifyCardInfoRequest = new HCService.CardInfoRequest(); 
        verifyCardInfoRequest.MerchantID = System.Configuration.ConfigurationManager.AppSettings["MerchantID"]; 
        verifyCardInfoRequest.Password = System.Configuration.ConfigurationManager.AppSettings["HCPassword"]; 
        verifyCardInfoRequest.CardID = txtCardID.Text; 
        
        //Call the VerifyCardInfo web method. 
        //HCService.HCService hcService = new HCService.HCService();
        HCService.HCServiceSoapClient hcWS = new HCService.HCServiceSoapClient();
        HCService.CardInfoResponse response = hcWS.VerifyCardInfo(verifyCardInfoRequest);

        txtResponseCode.Text   = response.ResponseCode.ToString();
        txtStatus.Text         = response.Status;
        txtStatusMessage.Text  = response.StatusMessage;
        txtDisplayMessage.Text = response.DisplayMessage;
        txtToken.Text          = response.Token;
        txtCardUsage.Text      = response.CardUsage;
        txtCardType.Text       = response.CardType;
        txtOperatorID.Text     = response.OperatorID;
        txtMaskedAcct.Text     = response.MaskedAccount;
        txtCardholderName.Text = response.CardHolderName;
        txtTranType.Text       = response.TranType;
        txtCardIDExpired.Text  = response.CardIDExpired.ToString();

        // save for payment by token example. note: this is for demonstration use only.
        SaveVerify(response.Token, response.MaskedAccount); 
    }


    private void SaveVerify(string Token, string MaskedAcct)
    {

        System.Configuration.Configuration config = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);
        AppSettingsSection appSettings = config.AppSettings;

        appSettings.Settings["Token"].Value = Token;
        appSettings.Settings["MaskedAcct"].Value = MaskedAcct;

        config.Save(ConfigurationSaveMode.Modified);

        ConfigurationManager.RefreshSection("appSettings");
    }
}